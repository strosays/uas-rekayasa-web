		</div>	
		<script>
                CKEDITOR.replace( 'editor1' );
            </script>
	</body>
	<div class="row" align="center">
		<?php
echo ('Copyright &copy; Putro '.date("Y"));
?> All rights reserved.
	</div>
</html>
